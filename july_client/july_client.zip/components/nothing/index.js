// components/nothing/index.js

Component({
  externalClasses: ['nothing-class'],
  properties: {
    pic: String,
    tip: {
      type: String,
      value: '暂时没有数据'
    }
  },
  data: {

  },
  methods: {

  }
})
