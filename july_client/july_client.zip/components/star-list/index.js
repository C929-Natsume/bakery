// components/star-list/index.js
Component({
  properties: {
    stars: Array
  },
  data: {

  },
  methods: {

  }
})
