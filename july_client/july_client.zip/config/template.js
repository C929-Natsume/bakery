export default {
  messageTemplateId: '3vJcgI1xs0ieSITvaIfaVWnbhth7noQOO1ZW6QZXbxw',
  reserveTemplateId: 'AKbgz2frqiCSXt_2V8dl2Un8MWwV5bFrDK8ASZYYe4s'
}