// pages/profile/index.js
import api from '../../config/api'
import wxutil from '../../miniprogram_npm/@yyjeffrey/wxutil/index'
import { init, upload } from '../../utils/qiniuUploader'
import { User } from '../../models/user'
import { Topic } from '../../models/topic'
import { Comment } from '../../models/comment'
import { Star } from '../../models/star'
import { Message } from '../../models/message'
import { OSS } from '../../models/oss'
import { Soul } from '../../models/soul'
import { EmotionStat } from '../../models/emotionStat'
import * as echarts from '../../components/ec-canvas/echarts'

const app = getApp()

Page({
  data: {
    user: null,
    topics: [],
    comments: [],
    stars: [],
    emotionStats: [],
    tabIndex: 0,
    tabsTop: 300,
    showImageClipper: false,
    tmpAvatar: '',
    messageBrief: null,
    topicPaging: null,
    commentPaging: null,
    starPaging: null,
    emotionStatPaging: null,
    hasMoreTopic: true,
    hasMoreComment: true,
    hasMoreStar: true,
    hasMoreEmotionStat: true,
    tabsFixed: false,
    loading: false,
    
    // 情绪统计相关
    uniqueEmotionCount: 0,
    totalEmotionCount: 0,
    
    // 心灵鸡汤相关
    showSoulPopup: false,
    soulMessage: {},
    soulLoading: false,
    soulTabIndex: 0,
    customMessage: '',
    customMessages: [],
    
    // 情绪统计图表相关
    showChartPopup: false,
    chartLoading: false,
    chartData: null,
    chartDays: 30,
    currentChartType: 'distribution',
    ec: {
      lazyLoad: true
    }
  },

  onLoad() {
    this.getUserInfo()
  },

  onShow() {
    this.getUserInfo(false)
    this.getMessages()
  },

  /**
   * 计算Tabs距离顶部的高度
   */
  getTabsTop() {
    const query = wx.createSelectorQuery()
    query.select('#tabs').boundingClientRect((res) => {
      this.setData({
        tabsTop: res.top
      })
    }).exec()
  },

  /**
   * 获取用户信息
   */
  async getUserInfo(loadPage = true) {
    let userDetail = app.globalData.userDetail
    if (!userDetail) {
      this.setData({
        user: null,
        topics: [],
        comments: [],
        stars: [],
        emotionStats: []
      })
      return
    }

    const userId = userDetail.id
    const user = await User.getUserInfo(userId)
    userDetail = Object.assign(userDetail, user)
    const deadtime = wxutil.getStorage('userDetail_deadtime')
    wxutil.setStorage('userDetail', userDetail)
    wxutil.setStorage('userDetail_deadtime', deadtime)

    app.globalData.userDetail = userDetail
    this.setData({
      user: userDetail
    })

    if (loadPage) {
      this.getTabsTop()
      wx.setNavigationBarTitle({
        title: userDetail.nickname
      })
    }

    this.initTopics(userId)
    this.initComments(userId)
    this.initStars(userId)
    this.initEmotionStats(userId)
  },

  /**
   * 初始化七牛云配置
   */
  async initQiniu() {
    const uptoken = await OSS.getQiniu()
    const options = {
      region: 'ECN',
      uptoken: uptoken,
      domain: api.ossDomain,
      shouldUseQiniuFileName: false
    }
    init(options)
  },

  /**
   * 初始化情绪统计
   */
  async initEmotionStats(userId) {
    try {
      const emotionStatPaging = await EmotionStat.getEmotionStatPaging({ 
        user_id: userId,
        page: 1,
        page_size: 20
      })
      
      this.setData({
        emotionStatPaging: emotionStatPaging
      })
      
      await this.getMoreEmotionStats(emotionStatPaging)
    } catch (error) {
      console.error('初始化情绪统计失败:', error)
    }
  },

  /**
   * 获取更多情绪统计
   */
  async getMoreEmotionStats(emotionStatPaging) {
    if (!emotionStatPaging || !emotionStatPaging.hasMore()) {
      this.setData({
        hasMoreEmotionStat: false
      })
      return
    }

    try {
      const data = await emotionStatPaging.getMore()
      if (data && data.accumulator) {
        this.setData({
          emotionStats: data.accumulator,
          hasMoreEmotionStat: data.hasMore
        })
        this.calculateEmotionSummary()
      }
    } catch (error) {
      console.error('获取更多情绪统计失败:', error)
    }
  },

  /**
   * 计算情绪统计摘要
   */
  calculateEmotionSummary() {
    const { emotionStats } = this.data
    
    // 计算唯一情绪类型数量
    const uniqueEmotions = new Set()
    let totalCount = 0
    
    emotionStats.forEach(stat => {
      if (stat.emotion_label && stat.emotion_label.name) {
        uniqueEmotions.add(stat.emotion_label.name)
      }
      totalCount += stat.count || 1
    })
    
    this.setData({
      uniqueEmotionCount: uniqueEmotions.size,
      totalEmotionCount: totalCount
    })
  },

  /**
   * 打开情绪统计图表
   */
  async openEmotionChart() {
    this.setData({
      showChartPopup: true,
      chartLoading: true
    })

    try {
      const userInfo = getApp().globalData.userInfo
      if (!userInfo) {
        throw new Error('用户信息不存在')
      }

      const emotionData = await EmotionStat.getCharts({
        user_id: userInfo.id,
        days: this.data.chartDays
      })
      
      this.setData({
        chartData: emotionData,
        chartLoading: false
      })
      
      // 渲染图表
      if (emotionData) {
        setTimeout(() => {
          this.renderChart(emotionData)
        }, 300)
      }
    } catch (error) {
      console.error('获取图表数据失败:', error)
      this.setData({
        chartLoading: false
      })
      wx.showToast({
        title: '加载图表失败',
        icon: 'none'
      })
    }
  },

  /**
   * 渲染图表
   */
  renderChart(chartData) {
    const chartComponent = this.selectComponent('#emotion-chart')
    if (!chartComponent) {
      console.error('图表组件未找到')
      setTimeout(() => this.renderChart(chartData), 100)
      return
    }

    chartComponent.init((canvas, width, height) => {
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height
      })

      const option = this.generateChartOption(chartData)
      chart.setOption(option)
      
      return chart
    })
  },

  /**
   * 生成图表配置选项
   */
  generateChartOption(chartData) {
    const { currentChartType } = this.data

    if (currentChartType === 'distribution') {
      return this.generatePieChartOption(chartData)
    } else if (currentChartType === 'trend') {
      return this.generateLineChartOption(chartData)
    }
    
    return {}
  },

  /**
   * 生成饼图配置（情绪分布）
   */
  generatePieChartOption(chartData) {
    const distribution = chartData.distribution || []
    
    // 准备饼图数据
    const pieData = distribution.map(item => ({
      name: item.emotion_label?.name || '未知情绪',
      value: item.count || 0,
      itemStyle: {
        color: item.emotion_label?.color || this.getRandomColor()
      }
    })).filter(item => item.value > 0) // 只显示有数据的情绪

    if (pieData.length === 0) {
      return {
        title: {
          text: '情绪分布统计',
          left: 'center',
          textStyle: { fontSize: 16, color: '#333' }
        },
        graphic: {
          type: 'text',
          left: 'center',
          top: 'middle',
          style: {
            text: '暂无数据',
            fontSize: 16,
            fill: '#999'
          }
        }
      }
    }

    return {
      title: {
        text: '情绪分布统计',
        left: 'center',
        textStyle: {
          fontSize: 16,
          color: '#333'
        }
      },
      tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b}: {c}次 ({d}%)'
      },
      legend: {
        orient: 'vertical',
        right: 10,
        top: 'center',
        textStyle: {
          fontSize: 12
        }
      },
      series: [
        {
          name: '情绪分布',
          type: 'pie',
          radius: ['40%', '70%'],
          avoidLabelOverlap: false,
          itemStyle: {
            borderColor: '#fff',
            borderWidth: 2
          },
          label: {
            show: true,
            formatter: '{b}: {c}次'
          },
          emphasis: {
            label: {
              show: true,
              fontSize: 14,
              fontWeight: 'bold'
            }
          },
          labelLine: {
            show: true
          },
          data: pieData
        }
      ]
    }
  },

  /**
   * 生成折线图配置（情绪趋势）
   */
  generateLineChartOption(chartData) {
    const trend = chartData.trend || {}
    
    // 获取所有日期并排序
    const dates = Object.keys(trend).sort()
    
    // 收集所有情绪标签
    const emotionLabels = new Set()
    dates.forEach(date => {
      const emotions = trend[date] || []
      emotions.forEach(emotion => {
        if (emotion.emotion_label?.name) {
          emotionLabels.add(emotion.emotion_label.name)
        }
      })
    })

    // 为每个情绪标签创建数据系列
    const series = Array.from(emotionLabels).map((label, index) => {
      const data = dates.map(date => {
        const emotions = trend[date] || []
        const emotionData = emotions.find(e => e.emotion_label?.name === label)
        return emotionData ? emotionData.count : 0
      })

      return {
        name: label,
        type: 'line',
        data: data,
        smooth: true,
        symbol: 'circle',
        symbolSize: 6,
        lineStyle: {
          width: 3
        },
        itemStyle: {
          color: this.getColorByIndex(index)
        }
      }
    })

    if (series.length === 0) {
      return {
        title: {
          text: '情绪趋势统计',
          left: 'center',
          textStyle: { fontSize: 16, color: '#333' }
        },
        graphic: {
          type: 'text',
          left: 'center',
          top: 'middle',
          style: {
            text: '暂无数据',
            fontSize: 16,
            fill: '#999'
          }
        }
      }
    }

    return {
      title: {
        text: '情绪趋势统计',
        left: 'center',
        textStyle: {
          fontSize: 16,
          color: '#333'
        }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: Array.from(emotionLabels),
        bottom: 10,
        textStyle: {
          fontSize: 12
        }
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '15%',
        top: '15%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: dates.map(date => {
          // 格式化日期显示
          const dateObj = new Date(date)
          return `${(dateObj.getMonth() + 1).toString().padStart(2, '0')}-${dateObj.getDate().toString().padStart(2, '0')}`
        }),
        axisLabel: {
          rotate: 45
        }
      },
      yAxis: {
        type: 'value',
        min: 0
      },
      series: series
    }
  },

  /**
   * 获取颜色（根据索引）
   */
  getColorByIndex(index) {
    const colors = [
      '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
      '#DDA0DD', '#87CEEB', '#98FB98', '#FFD700', '#FFA07A',
      '#20B2AA', '#DEB887', '#5F9EA0', '#FF69B4', '#00FA9A'
    ]
    return colors[index % colors.length]
  },

  /**
   * 获取随机颜色
   */
  getRandomColor() {
    const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD']
    return colors[Math.floor(Math.random() * colors.length)]
  },

  /**
   * 关闭图表弹窗
   */
  closeChartPopup() {
    this.setData({
      showChartPopup: false,
      chartData: null
    })
  },

  /**
   * 切换图表类型
   */
  switchChartType(e) {
    const chartType = e.currentTarget.dataset.type
    if (this.data.currentChartType === chartType) return
    
    this.setData({
      currentChartType: chartType
    }, () => {
      this.openEmotionChart()
    })
  },

  /**
   * 切换统计天数
   */
  changeChartDays(e) {
    const days = parseInt(e.currentTarget.dataset.days)
    if (this.data.chartDays === days) return
    
    this.setData({
      chartDays: days
    }, () => {
      this.openEmotionChart()
    })
  },

  /**
   * 查看情绪统计详情
   */
  viewEmotionDetail(e) {
    const index = e.currentTarget.dataset.index
    const stat = this.data.emotionStats[index]
    
    if (stat && stat.id) {
      wx.navigateTo({
        url: `/pages/emotion-detail/index?id=${stat.id}`
      })
    }
  },

  /**
   * 删除情绪统计记录
   */
  deleteEmotionStat(e) {
    const index = e.currentTarget.dataset.index
    const stat = this.data.emotionStats[index]
    
    if (!stat || !stat.id) {
      wx.showToast({
        title: '记录不存在',
        icon: 'none'
      })
      return
    }

    const dialog = this.selectComponent('#dialog')
    dialog.linShow({
      type: 'confirm',
      title: '提示',
      content: '确定要删除该情绪记录？',
      success: async (res) => {
        if (res.confirm) {
          try {
            const result = await EmotionStat.deleteEmotionStat(stat.id)
            if (result.code === 0) {
              // 从列表中移除
              const emotionStats = [...this.data.emotionStats]
              emotionStats.splice(index, 1)
              
              this.setData({ emotionStats })
              this.calculateEmotionSummary()

              wx.lin.showMessage({
                type: 'success',
                content: '删除成功！'
              })
            } else {
              throw new Error(result.message || '删除失败')
            }
          } catch (error) {
            console.error('删除情绪统计失败:', error)
            wx.lin.showMessage({
              type: 'error',
              content: error.message || '删除失败！'
            })
          }
        }
      }
    })
  },

  // 其他原有方法保持不变...
  async initTopics(userId) {
    const topicPaging = await Topic.getTopicPaging({ user_id: userId })
    this.setData({
      topicPaging: topicPaging
    })
    await this.getMoreTopics(topicPaging)
  },

  async getMoreTopics(topicPaging) {
    const data = await topicPaging.getMore()
    if (!data) {
      return
    }
    this.setData({
      topics: data.accumulator,
      hasMoreTopic: data.hasMore
    })
  },

  async initComments(userId) {
    const commentPaging = await Comment.getCommentPaging({ user_id: userId })
    this.setData({
      commentPaging: commentPaging
    })
    await this.getMoreComments(commentPaging)
  },

  async getMoreComments(commentPaging) {
    const data = await commentPaging.getMore()
    if (!data) {
      return
    }
    this.setData({
      comments: data.accumulator,
      hasMoreComment: data.hasMore
    })
  },

  async initStars(userId) {
    const starPaging = await Star.getStarPaging({ user_id: userId })
    this.setData({
      starPaging: starPaging
    })
    await this.getMoreStars(starPaging)
  },

  async getMoreStars(starPaging) {
    const data = await starPaging.getMore()
    if (!data) {
      return
    }
    this.setData({
      stars: data.accumulator,
      hasMoreStar: data.hasMore
    })
  },

  async getMessages() {
    if (!app.globalData.userDetail) {
      return
    }

    const data = await Message.getMessages()
    if (data && data.length > 0) {
      this.setData({
        messageBrief: data
      })
      wx.setTabBarBadge({
        index: 2,
        text: data.length.toString()
      })
    } else {
      this.setData({
        messageBrief: null
      })
      wx.removeTabBarBadge({
        index: 2
      })
    }
  },

  changeTabs(event) {
    const tabIndex = event.detail.currentIndex
    this.setData({
      tabIndex: tabIndex
    })
    if (this.data.tabsFixed) {
      wx.pageScrollTo({
        scrollTop: this.data.tabsTop
      })
    }
  },

  gotoMessage() {
    wx.navigateTo({
      url: '/pages/message/index'
    })
  },

  async changePoster() {
    if (!this.data.user) {
      return
    }
    wx.lin.showMessage({
      content: '设置封面图片'
    })

    wxutil.image.choose(1).then(async res => {
      if (res.errMsg !== 'chooseImage:ok') {
        return
      }

      wxutil.showLoading('上传中...')
      await this.initQiniu()
      const poster = await this.sendMedia(res.tempFilePaths[0], 'poster')

      const data = {
        avatar: this.data.user.avatar,
        nickname: this.data.user.nickname,
        signature: this.data.user.signature,
        gender: this.data.user.gender,
        poster: poster
      }
      const info = await User.updateUser(data)
      if (info.code === 2) {
        this.getUserInfo(false)
        wx.lin.showMessage({
          type: 'success',
          content: '封面修改成功！',
        })
      } else {
        wx.lin.showMessage({
          type: 'error',
          content: '封面修改失败！'
        })
      }
      wx.hideLoading()
    })
  },

  changeAvatar(event) {
    if (!this.data.user) {
      return
    }
    wx.lin.showMessage({
      content: '设置头像图片'
    })
    this.setData({
      tmpAvatar: event.detail.detail.avatarUrl,
      showImageClipper: true
    })
  },

  async onClipTap(event) {
    wxutil.showLoading('上传中...')
    await this.initQiniu()
    const avatar = await this.sendMedia(event.detail.url, 'avatar')

    const data = {
      avatar: avatar,
      nickname: this.data.user.nickname,
      signature: this.data.user.signature,
      gender: this.data.user.gender
    }
    const res = await User.updateUser(data)
    if (res.code === 2) {
      this.getUserInfo(false)
      wx.lin.showMessage({
        type: 'success',
        content: '头像修改成功！',
      })
    } else {
      wx.lin.showMessage({
        type: 'error',
        content: '头像修改失败！'
      })
    }
    wx.hideLoading()

    this.setData({
      showImageClipper: false,
    })
  },

  sendMedia(imageFile, path) {
    return new Promise((resolve, reject) => {
      upload(imageFile, (res) => {
        resolve(res.imageURL)
      }, (error) => {
        reject(error)
      }, {
        region: 'ECN',
        uptoken: null,
        domain: null,
        shouldUseQiniuFileName: false,
        key: path + '/' + wxutil.getUUID(false)
      })
    })
  },

  async onReachBottom() {
    const tabIndex = this.data.tabIndex
    this.setData({
      loading: true
    })
    if (tabIndex === 0) {
      await this.getMoreTopics(this.data.topicPaging)
    }
    else if (tabIndex === 1) {
      await this.getMoreComments(this.data.commentPaging)
    }
    else if (tabIndex === 2) {
      await this.getMoreStars(this.data.starPaging)
    }
    else if (tabIndex === 3) {
      await this.getMoreEmotionStats(this.data.emotionStatPaging)
    }
    this.setData({
      loading: false
    })
  },

  deleteTopic(event) {
    const dialog = this.selectComponent('#dialog')
    dialog.linShow({
      type: 'confirm',
      title: '提示',
      content: '确定要删除该话题？',
      success: async (res) => {
        if (res.confirm) {
          const topics = this.data.topics
          const index = event.detail.index

          const res = await Topic.deleteTopic(topics[index].id)
          if (res.code === 3) {
            topics.splice(index, 1)
            this.setData({
              topics: topics
            })
            wx.lin.showMessage({
              type: 'success',
              content: '删除成功！'
            })
          } else {
            wx.lin.showMessage({
              type: 'error',
              content: '删除失败！'
            })
          }
        }
      }
    })
  },

  deleteComment(event) {
    const dialog = this.selectComponent('#dialog')
    dialog.linShow({
      type: 'confirm',
      title: '提示',
      content: '确定要删除该评论？',
      success: async (res) => {
        if (res.confirm) {
          const comments = this.data.comments
          const index = event.detail.index

          const res = await Comment.deleteComment(comments[index].id)
          if (res.code === 3) {
            comments.splice(index, 1)
            this.setData({
              comments: comments
            })
            wx.lin.showMessage({
              type: 'success',
              content: '删除成功！'
            })
          } else {
            wx.lin.showMessage({
              type: 'error',
              content: '删除失败！'
            })
          }
        }
      }
    })
  },

  deleteStar(event) {
    const dialog = this.selectComponent('#dialog')
    dialog.linShow({
      type: 'confirm',
      title: '提示',
      content: '确定要取消收藏该话题？',
      success: async (res) => {
        if (res.confirm) {
          const stars = this.data.stars
          const index = event.detail.index

          const res = await Star.starOrCancel(stars[index].topic.id)
          if (res.code === 0) {
            stars.splice(index, 1)
            this.setData({
              stars: stars
            })
            wx.lin.showMessage({
              type: 'success',
              content: '取消收藏成功！'
            })
          } else {
            wx.lin.showMessage({
              type: 'error',
              content: '取消收藏失败！'
            })
          }
        }
      }
    })
  },

  onPageScroll(event) {
    if (event.scrollTop >= this.data.tabsTop) {
      this.setData({
        tabsFixed: true
      })
    } else {
      this.setData({
        tabsFixed: false
      })
    }
  },

  onPullDownRefresh() {
    this.getUserInfo(false)
    this.getMessages()
    wx.stopPullDownRefresh()
    wx.vibrateShort()
  },

  onShareAppMessage() {
    return {
      title: '个人中心',
      path: '/pages/profile/index'
    }
  },

  // 心灵鸡汤相关方法
  async openSoulMessage() {
    const waitingMessages = [
      "Life is like a box of chocolates, you never know what you're gonna get."
    ]
    
    const randomWaiting = waitingMessages[Math.floor(Math.random() * waitingMessages.length)]
    
    this.setData({
      showSoulPopup: true,
      soulTabIndex: 0,
      soulLoading: true,
      soulMessage: {
        content: randomWaiting,
        push_id: null,
        source: 'waiting'
      }
    })

    try {
      const res = await Soul.getSmartPush()
      if (res && res.code === 0 && res.data) {
        const data = res.data
        const confidencePercent = data.confidence ? Math.round(data.confidence * 100) : 0
        
        this.setData({
          soulMessage: {
            push_id: data.push_id,
            content: data.content,
            emotion_label: data.emotion_label,
            confidence: data.confidence,
            confidence_percent: confidencePercent,
            source: data.source,
            is_collected: false
          },
          soulLoading: false
        })
      } else {
        this.setData({
          soulLoading: false
        })
      }
    } catch (error) {
      console.error('获取智能推送失败:', error)
      this.setData({
        soulLoading: false
      })
    }
  },

  closeSoulPopup() {
    this.setData({
      showSoulPopup: false,
      soulMessage: {}
    })
  },

  preventClose() {
    // 空函数，阻止事件冒泡
  },

  async collectSoulMessage() {
    if (!this.data.soulMessage.push_id) {
      return
    }

    try {
      const res = await Soul.toggleCollect(this.data.soulMessage.push_id)
      if (res.code === 0) {
        this.setData({
          'soulMessage.is_collected': res.data.is_collected
        })
        wx.showToast({
          title: res.data.is_collected ? '收藏成功' : '已取消收藏',
          icon: 'success'
        })
      }
    } catch (error) {
      console.error('收藏失败:', error)
      wx.showToast({
        title: '操作失败',
        icon: 'none'
      })
    }
  },

  switchSoulTab(e) {
    const index = parseInt(e.currentTarget.dataset.index)
    this.setData({
      soulTabIndex: index,
      customMessage: ''
    })
  },

  onCustomMessageInput(e) {
    this.setData({
      customMessage: e.detail.value
    })
  },

  async saveCustomMessage() {
    const message = this.data.customMessage.trim()
    
    if (!message) {
      wx.showToast({
        title: '请输入句子',
        icon: 'none'
      })
      return
    }
    
    if (message.length > 500) {
      wx.showToast({
        title: '句子太长，最多500字',
        icon: 'none'
      })
      return
    }
    
    wx.showLoading({
      title: '保存中...'
    })
    
    try {
      const res = await Soul.saveCustom(message)
      if (res.code === 0) {
        const data = res.data
        const createdCount = data.created_count || 1
        
        wx.showToast({
          title: `保存成功（已创建${createdCount}条记录）`,
          icon: 'success',
          duration: 2000
        })
        
        this.setData({
          customMessage: '',
          soulTabIndex: 0,
          soulMessage: {
            push_id: data.push_id,
            content: data.content,
            emotion_label: data.emotion_label,
            emotion_name: data.emotion_name,
            source: 'user_custom',
            is_collected: false
          },
          soulLoading: false
        })
      } else {
        wx.showToast({
          title: res.msg || '保存失败',
          icon: 'none'
        })
      }
    } catch (error) {
      console.error('保存自定义句子失败:', error)
      wx.showToast({
        title: '网络错误',
        icon: 'none'
      })
    } finally {
      wx.hideLoading()
    }
  },

  cancelAddMessage() {
    this.setData({
      customMessage: '',
      soulTabIndex: 0
    })
  }
})